OP Auto Clicker
A simple auto clicker for Windows.
Unzip and run OP AutoClicker.exe.
Click Bind to set the start/stop hotkey (default F8).
